# APP Monitor
Projet Java EE pour faciliter la gestion de l'APP

###Pre-configurations :

* Installer Mysql .
* Cr�er  une BDD avec le nom 'gestionscolarite' avec   #user : root ,  #password : ""

### Technologies 
*  Spring 
*  Spring mvc
*  Hibernate
*  CSS/Bootstrap
*  JS/Jquery
*  HTML5

