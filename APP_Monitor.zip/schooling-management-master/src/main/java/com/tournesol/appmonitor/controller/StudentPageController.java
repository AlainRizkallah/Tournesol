package com.tournesol.appmonitor.controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.tournesol.appmonitor.dao.niveau.NiveauDao;
import com.tournesol.appmonitor.dao.note.NoteDao;
import com.tournesol.appmonitor.model.Niveau;
import com.tournesol.appmonitor.model.Note;


@Controller
@RequestMapping(value = "/student")
public class StudentPageController
{

	@Resource
	NoteDao noteDao;

	@Resource
	NiveauDao niveauDao;

	// Accueil
	@RequestMapping(method = RequestMethod.GET)
	public String home(final Model model)
	{

		return "student/studentHome";
	}

	//Afficher les notes
	@RequestMapping(value = "/showNote", method = RequestMethod.GET)
	public String showProf(final Model model)
	{
		final List<Note> notes = noteDao.findAll();
		model.addAttribute("notes", notes);
		return "student/showNote";
	}

	//Afficher le planning
	@RequestMapping(value = "/planning", method = RequestMethod.GET)
	public String planning(final Model model)
	{
		final List<Niveau> niveaux = niveauDao.findAll();
		model.addAttribute("niveaux", niveaux);

		return "student/planning";
	}
}
