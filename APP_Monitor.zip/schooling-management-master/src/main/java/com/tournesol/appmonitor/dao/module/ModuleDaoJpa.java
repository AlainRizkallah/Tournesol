package com.tournesol.appmonitor.dao.module;

import org.springframework.stereotype.Repository;

import com.tournesol.appmonitor.dao.GenericJpaDao;
import com.tournesol.appmonitor.model.Module;

@Repository("moduleDao")
public class ModuleDaoJpa extends GenericJpaDao<Module, Long> implements ModuleDao{

	public ModuleDaoJpa() {
		super(Module.class);
	}
}
