package com.tournesol.appmonitor.dao.user;

import java.util.List;

import com.tournesol.appmonitor.dao.GenericDao;
import com.tournesol.appmonitor.model.Etudiant;
import com.tournesol.appmonitor.model.Matiere;
import com.tournesol.appmonitor.model.User;



public interface MatiereDao extends GenericDao<Matiere, Long>
{
	List<Etudiant> getStudentsForSubject(String idMatiere);
}
