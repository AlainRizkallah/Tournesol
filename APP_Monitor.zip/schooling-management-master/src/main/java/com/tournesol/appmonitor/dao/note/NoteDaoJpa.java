package com.tournesol.appmonitor.dao.note;

import org.springframework.stereotype.Repository;

import com.tournesol.appmonitor.dao.GenericJpaDao;
import com.tournesol.appmonitor.model.Note;


@Repository("noteDao")
public class NoteDaoJpa extends GenericJpaDao<Note, Long> implements NoteDao{

	public NoteDaoJpa() {
		super(Note.class);
		
	}

	
}
