package com.tournesol.appmonitor.dao.module;

import com.tournesol.appmonitor.dao.GenericDao;
import com.tournesol.appmonitor.model.Module;


public interface ModuleDao extends GenericDao<Module, Long>
{
}


