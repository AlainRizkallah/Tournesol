package com.tournesol.appmonitor.dao.niveau;

import com.tournesol.appmonitor.dao.GenericDao;
import com.tournesol.appmonitor.model.Niveau;


public interface NiveauDao extends GenericDao<Niveau, Long>
{
}


