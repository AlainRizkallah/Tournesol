package com.tournesol.appmonitor.dao.niveau;

import org.springframework.stereotype.Repository;

import com.tournesol.appmonitor.dao.GenericJpaDao;
import com.tournesol.appmonitor.model.Niveau;


@Repository("niveauDao")
public class NiveauDaoJpa extends GenericJpaDao<Niveau, Long> implements NiveauDao{
	
	public NiveauDaoJpa()
	{
		super(Niveau.class);
	}
	}
