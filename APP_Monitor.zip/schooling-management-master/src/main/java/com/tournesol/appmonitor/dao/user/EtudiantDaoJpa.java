package com.tournesol.appmonitor.dao.user;



import org.springframework.stereotype.Repository;

import com.tournesol.appmonitor.dao.GenericJpaDao;
import com.tournesol.appmonitor.model.Etudiant;


@Repository("etudiantDao")
public class EtudiantDaoJpa extends GenericJpaDao<Etudiant, Long> implements EtudiantDao
{
	public EtudiantDaoJpa()
	{
		super(Etudiant.class);
	}
}
