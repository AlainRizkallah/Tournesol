package com.tournesol.appmonitor.model;

import javax.persistence.Entity;


@Entity
public class Administrateur extends User{
	

}
