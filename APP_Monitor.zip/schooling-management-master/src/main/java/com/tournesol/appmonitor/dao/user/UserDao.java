package com.tournesol.appmonitor.dao.user;

import com.tournesol.appmonitor.dao.GenericDao;
import com.tournesol.appmonitor.model.User;


public interface UserDao extends GenericDao<User, Long>
{
	User checkRegistredUser(String userName, String password);
}
