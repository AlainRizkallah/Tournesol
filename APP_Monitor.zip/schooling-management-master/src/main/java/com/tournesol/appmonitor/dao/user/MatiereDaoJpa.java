package com.tournesol.appmonitor.dao.user;
import java.util.List;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.tournesol.appmonitor.dao.GenericJpaDao;
import com.tournesol.appmonitor.model.Etudiant;
import com.tournesol.appmonitor.model.Matiere;
import com.tournesol.appmonitor.model.Niveau;


@Repository("matiereDao")
public class MatiereDaoJpa extends GenericJpaDao<Matiere, Long> implements MatiereDao
{
	public MatiereDaoJpa()
	{
		super(Matiere.class);
	}

	@Override
	@Transactional
	public List<Etudiant> getStudentsForSubject(String idMatiere) {
		
		Matiere matiere = findById(Long.valueOf(idMatiere));
		Niveau niveau = matiere.getNiveau();
		List<Etudiant> etudiants = niveau.getEtudiants();
		return etudiants ; 
	}
}
