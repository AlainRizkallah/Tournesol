package com.tournesol.appmonitor.dao.user;



import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.tournesol.appmonitor.dao.GenericJpaDao;
import com.tournesol.appmonitor.model.Administrateur;
import com.tournesol.appmonitor.model.Etudiant;
import com.tournesol.appmonitor.model.Professeur;
import com.tournesol.appmonitor.model.User;


@Repository("userDao")
public class UserDaoJpa extends GenericJpaDao<User, Long> implements UserDao
{
	public UserDaoJpa()
	{
		super(User.class);
	}

	@Override
	public User checkRegistredUser(final String login, final String password)
	{
		final Query query = getEntityManager().createQuery(
				"select u from " + getPersistentClass().getSimpleName() + " u where u.login = :login and u.password = :password");
		query.setParameter("login", login);
		query.setParameter("password", password);

		final List results = query.getResultList();

		if (results != null && !results.isEmpty())
		{
			final User user = (User) results.get(0);
	   		return user ; 
		}
		
		return null;
	}
}
