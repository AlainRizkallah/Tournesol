package com.tournesol.appmonitor.dao.user;

import com.tournesol.appmonitor.dao.GenericDao;
import com.tournesol.appmonitor.model.Etudiant;


public interface EtudiantDao extends GenericDao<Etudiant, Long>
{

}
