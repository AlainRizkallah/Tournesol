package com.tournesol.appmonitor.dao.note;

import com.tournesol.appmonitor.dao.GenericDao;
import com.tournesol.appmonitor.model.Note;



public interface NoteDao extends GenericDao<Note, Long>
{
}




