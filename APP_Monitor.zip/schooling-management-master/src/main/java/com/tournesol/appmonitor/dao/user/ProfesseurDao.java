package com.tournesol.appmonitor.dao.user;

import com.tournesol.appmonitor.dao.GenericDao;
import com.tournesol.appmonitor.model.Etudiant;
import com.tournesol.appmonitor.model.Professeur;


public interface ProfesseurDao extends GenericDao<Professeur, Long>
{

}
