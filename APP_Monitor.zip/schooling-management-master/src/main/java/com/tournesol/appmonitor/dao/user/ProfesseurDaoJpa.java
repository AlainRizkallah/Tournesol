package com.tournesol.appmonitor.dao.user;



import org.springframework.stereotype.Repository;

import com.tournesol.appmonitor.dao.GenericJpaDao;
import com.tournesol.appmonitor.model.Professeur;


@Repository("ProfesseurDao")
public class ProfesseurDaoJpa extends GenericJpaDao<Professeur, Long> implements ProfesseurDao
{
	public ProfesseurDaoJpa()
	{
		super(Professeur.class);
	}
}
